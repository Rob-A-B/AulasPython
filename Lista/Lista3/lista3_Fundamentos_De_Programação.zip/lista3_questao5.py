soma = 0.0
for i in range(5):
    idade = int(input("Digite a sua idade\n"))
    soma = soma + idade
media = soma / 5
print(" media de idade é: ", media)
