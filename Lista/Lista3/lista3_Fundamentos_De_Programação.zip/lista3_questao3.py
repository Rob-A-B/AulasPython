auxilio=150
funcionarios=30
for i in range(funcionarios):
    qtd = int(input("Digite a quantidade de filhos\n"))
    print("O bonus é de :",qtd*auxilio)